use ITI

-----------------1
CREATE FUNCTION dbo.GetMonthNameByDate (@Date DATE)
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @MonthName VARCHAR(20);

    SET @MonthName = DATENAME(MONTH, @Date);

    RETURN @MonthName;
END;

-----------------2

CREATE FUNCTION dbo.GetNumbersBtwTwoInt
(
    @StartInt INT,
    @EndInt INT
)
RETURNS @Result TABLE (Value INT)
AS
BEGIN
    DECLARE @Current INT;

    IF @StartInt <= @EndInt
    BEGIN
        SET @Current = @StartInt;
        WHILE @Current <= @EndInt
        BEGIN
            INSERT INTO @Result (Value) VALUES (@Current);
            SET @Current = @Current + 1;
        END
    END
    ELSE
    BEGIN
        SET @Current = @StartInt;
        WHILE @Current >= @EndInt
        BEGIN
            INSERT INTO @Result (Value) VALUES (@Current);
            SET @Current = @Current - 1;
        END
    END

    RETURN;
END;

-----------------3

CREATE FUNCTION dbo.GetStudentInfoById
(
    @StudentID INT
)
RETURNS @Result TABLE
(
    FullName VARCHAR(101),
    DepartmentName VARCHAR(100)
)
AS
BEGIN
    INSERT INTO @Result (FullName, DepartmentName)
    SELECT 
        CONCAT(St_Fname, ' ', St_Lname) AS FullName,
        D.Dept_Name
    FROM Student S
    INNER JOIN Department D ON S.Dept_Id = D.Dept_Id
    WHERE S.St_Id = @StudentID;

    RETURN;
END;

-----------------4

CREATE FUNCTION dbo.CheckStudentNameStatus
(
    @StudentID INT
)
RETURNS VARCHAR(100)
AS
BEGIN
    DECLARE @FirstName VARCHAR(50);
    DECLARE @LastName VARCHAR(50);
    DECLARE @Message VARCHAR(100);

    SELECT 
        @FirstName = St_Fname,
        @LastName = St_Lname
    FROM Student
    WHERE St_Id = @StudentID;

    if @FirstName IS NULL AND @LastName IS NULL
        select @Message = 'First name & last name are null';
    else if @FirstName IS NULL
        select @Message = 'First name is null';
    else if @LastName IS NULL
        select @Message = 'Last name is null';
    else
        select @Message = 'First name & last name are not null';

    return @Message;
END;

-----------------5
use MyCompany

CREATE FUNCTION dbo.GetManagerInfoByHiringDate
(
    @date INT
)
RETURNS @Result TABLE
(
    DepartmentName VARCHAR(100),
    ManagerName VARCHAR(101),
    FormattedHireDate VARCHAR(50)
)
AS
BEGIN
    INSERT INTO @Result (DepartmentName, ManagerName, FormattedHireDate)
    SELECT 
        d.Dname,
        CONCAT(M.Fname, ' ', M.Lname) AS ManagerName,
        CONVERT(VARCHAR(50), d.[MGRStart Date], @date) AS FormattedHireDate
    FROM Departments d
    INNER JOIN Employee M ON M.SSN = d.MGRSSN;

    RETURN;
END;

-------------------6
use ITI

CREATE FUNCTION dbo.GetStudentNameByType
(
    @NameType VARCHAR(20)
)
RETURNS @Result TABLE
(
    StudentID INT,
    NameOutput VARCHAR(101)
)
AS
BEGIN
    IF @NameType = 'first name'
    BEGIN
        INSERT INTO @Result (StudentID, NameOutput)
        SELECT 
            St_Id,
            ISNULL(St_Fname, null) AS NameOutput
        FROM Student;
    END
    ELSE IF @NameType = 'last name'
    BEGIN
        INSERT INTO @Result (StudentID, NameOutput)
        SELECT 
            St_Id,
            ISNULL(St_Lname, null) AS NameOutput
        FROM Student;
    END
    ELSE IF @NameType = 'full name'
    BEGIN
        INSERT INTO @Result (StudentID, NameOutput)
        SELECT 
            St_Id,
            ISNULL(St_Fname, '') + ' ' + ISNULL(St_Lname, '') AS NameOutput
        FROM Student;
    END

    RETURN;
END;
 ----------------------7

 use MyCompany

CREATE FUNCTION dbo.GetEmployeesByProject
(
    @Pnumber INT
)
RETURNS @Result TABLE
(
    SSN INT,
    FullName NVARCHAR(101),
    DepartmentName NVARCHAR(50)
)
AS
BEGIN
    INSERT INTO @Result (SSN, FullName, DepartmentName)
    SELECT 
        E.SSN,
        ISNULL(E.Fname, '') + ' ' + ISNULL(E.Lname, '') AS FullName,
        D.Dname
    FROM Project P
    INNER JOIN Departments D ON P.Dnum = D.Dnum
    INNER JOIN Employee E ON E.Dno = D.Dnum
    WHERE P.Pnumber = @Pnumber;

    RETURN;
END;
